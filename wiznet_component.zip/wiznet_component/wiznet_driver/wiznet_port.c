#include "wiznet_port.h"
#include "wizchip_conf.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include <string.h>

static const char *TAG = "wiznet_port";
static spi_device_handle_t s_spi;
static SemaphoreHandle_t s_cris_mutex;

/* ---------- Critical section (bảo vệ 1 chuỗi lệnh SPI không bị chen ngang) ---------- */
static void wiznet_cris_enter(void)
{
    xSemaphoreTake(s_cris_mutex, portMAX_DELAY);
}

static void wiznet_cris_exit(void)
{
    xSemaphoreGive(s_cris_mutex);
}

/* ---------- Chip select ----------
 * spics_io_num của spi_device đã tự quản lý CS theo từng transaction,
 * nên 2 hàm này để trống (no-op) là đúng và AN TOÀN nhất khi dùng
 * spi_device_transmit của ESP-IDF. Nếu bạn tự kéo CS tay ở đây nữa sẽ
 * bị đá nhau với driver SPI, dễ gây lỗi y hệt "reset timeout" đã gặp.
 */
static void wiznet_cs_select(void)   {}
static void wiznet_cs_deselect(void) {}

/* ---------- SPI 1 byte (không dùng khi đã có burst, nhưng vẫn phải đăng ký) ---------- */
static uint8_t wiznet_spi_read_byte(void)
{
    uint8_t rx = 0;
    spi_transaction_t t = {
        .length = 8,
        .rxlength = 8,
        .tx_buffer = NULL,
        .rx_buffer = &rx,
        .flags = SPI_TRANS_USE_RXDATA,
    };
    spi_device_transmit(s_spi, &t);
    return t.rx_data[0];
}

static void wiznet_spi_write_byte(uint8_t wb)
{
    spi_transaction_t t = {
        .length = 8,
        .tx_buffer = NULL,
        .flags = SPI_TRANS_USE_TXDATA,
    };
    t.tx_data[0] = wb;
    spi_device_transmit(s_spi, &t);
}

/* ---------- SPI burst (đọc/ghi nhiều byte 1 lần — nhanh hơn nhiều, nên dùng) ---------- */
static void wiznet_spi_read_burst(uint8_t *pBuf, uint16_t len)
{
    if (len == 0) return;
    spi_transaction_t t = {
        .length = (size_t)len * 8,
        .rxlength = (size_t)len * 8,
        .tx_buffer = NULL,
        .rx_buffer = pBuf,
    };
    esp_err_t err = spi_device_transmit(s_spi, &t);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "spi_device_transmit(read_burst) loi: %s", esp_err_to_name(err));
    }
}

static void wiznet_spi_write_burst(uint8_t *pBuf, uint16_t len)
{
    if (len == 0) return;
    spi_transaction_t t = {
        .length = (size_t)len * 8,
        .tx_buffer = pBuf,
        .rx_buffer = NULL,
    };
    esp_err_t err = spi_device_transmit(s_spi, &t);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "spi_device_transmit(write_burst) loi: %s", esp_err_to_name(err));
    }
}

/* ---------- Reset phần cứng W5500 (y hệt trình tự đã test bằng SPI thô) ---------- */
static void wiznet_hw_reset(void)
{
    gpio_config_t rst_cfg = {
        .pin_bit_mask = (1ULL << W5500_RST_GPIO),
        .mode = GPIO_MODE_OUTPUT,
    };
    gpio_config(&rst_cfg);
    gpio_set_level(W5500_RST_GPIO, 0);
    vTaskDelay(pdMS_TO_TICKS(10));
    gpio_set_level(W5500_RST_GPIO, 1);
    vTaskDelay(pdMS_TO_TICKS(50));
}

esp_err_t wiznet_port_init(void)
{
    esp_err_t err;

    s_cris_mutex = xSemaphoreCreateMutex();
    if (s_cris_mutex == NULL) {
        ESP_LOGE(TAG, "Khong tao duoc mutex");
        return ESP_ERR_NO_MEM;
    }

    // --- 1. Reset chip trước, giống hệt bước đã kiểm chứng thành công ---
    wiznet_hw_reset();

    // --- 2. Khởi tạo bus SPI ---
    spi_bus_config_t buscfg = {
        .miso_io_num = W5500_MISO_GPIO,
        .mosi_io_num = W5500_MOSI_GPIO,
        .sclk_io_num = W5500_SCLK_GPIO,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = 2048,
    };
    err = spi_bus_initialize(W5500_SPI_HOST, &buscfg, SPI_DMA_CH_AUTO);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "spi_bus_initialize loi: %s", esp_err_to_name(err));
        return err;
    }

    spi_device_interface_config_t devcfg = {
        .mode = 0,
        .clock_speed_hz = W5500_SPI_CLOCK_HZ,
        .queue_size = 4,
        .spics_io_num = W5500_CS_GPIO,   // để driver SPI tự quản lý CS theo transaction
        .cs_ena_pretrans = 2,
        .cs_ena_posttrans = 2,
    };
    err = spi_bus_add_device(W5500_SPI_HOST, &devcfg, &s_spi);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "spi_bus_add_device loi: %s", esp_err_to_name(err));
        return err;
    }

    // --- 3. Đăng ký các callback cho ioLibrary_Driver ---
    reg_wizchip_cris_cbfunc(wiznet_cris_enter, wiznet_cris_exit);
    reg_wizchip_cs_cbfunc(wiznet_cs_select, wiznet_cs_deselect);
    reg_wizchip_spi_cbfunc(wiznet_spi_read_byte, wiznet_spi_write_byte);
    reg_wizchip_spiburst_cbfunc(wiznet_spi_read_burst, wiznet_spi_write_burst);

    // --- 4. Cấp phát bộ nhớ 8 socket: mỗi socket 2KB TX + 2KB RX (tổng đúng 16KB+16KB của W5500) ---
    uint8_t tx_sizes[8] = {2, 2, 2, 2, 2, 2, 2, 2};
    uint8_t rx_sizes[8] = {2, 2, 2, 2, 2, 2, 2, 2};
    if (wizchip_init(tx_sizes, rx_sizes) != 0) {
        ESP_LOGE(TAG, "wizchip_init that bai");
        return ESP_FAIL;
    }

    ESP_LOGI(TAG, "wiznet_port_init OK");
    return ESP_OK;
}
