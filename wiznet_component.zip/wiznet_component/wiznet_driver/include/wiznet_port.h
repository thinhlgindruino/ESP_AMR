#pragma once
/*
 * wiznet_port.h
 * Lớp "adapter" nối phần cứng ESP32 (GPIO reset, SPI) với ioLibrary_Driver
 * của WIZnet. Dùng lại đúng chân và trình tự reset bạn đã test thành công
 * bằng SPI thô (VERSIONR = 0x04).
 */

#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "esp_err.h"

// ==== Đổi lại cho khớp board của bạn ====
#define W5500_MISO_GPIO   19
#define W5500_MOSI_GPIO   23
#define W5500_SCLK_GPIO   18
#define W5500_CS_GPIO      5
#define W5500_RST_GPIO    22
#define W5500_SPI_HOST     SPI2_HOST
#define W5500_SPI_CLOCK_HZ (8 * 1000 * 1000)   // có thể thử tăng dần: 1MHz -> 8MHz -> 20MHz

/**
 * @brief Khởi tạo GPIO reset + bus SPI + đăng ký callback cho ioLibrary_Driver.
 *        Gọi hàm này trước khi gọi wizchip_init().
 */
esp_err_t wiznet_port_init(void);
